import SignUp from "@/app/signup/page";

const HomePage = () => {
  return (
    // <div className="dark:bg-[#181B33] bg-[#F2F2F2] min-h-screen h-screen-minus-80 flex justify-center items-center"></div>
    <div>
      <SignUp />
    </div>
  );
};

export default HomePage;
